var Tree;
(function() {

(Tree = function(conf) {
}).prototype = {

};

})();
