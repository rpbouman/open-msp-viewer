var Timer;

(function(){
(Timer = function(conf){
  this.conf = conf || {};
}).prototype = {
  start: function(delay){
    var me = this;
    me.cancel();
    me.timeout = win.setTimeout(function(){
      me.expire();
    }, delay || this.conf.delay);
  },
  cancel: function(){
    if (this.timeout) {
      win.clearTimeout(this.timeout);
    }
  },
  expire: function(){
    this.fireEvent("expired");
  }
};

adopt(Timer, Observable);
})();