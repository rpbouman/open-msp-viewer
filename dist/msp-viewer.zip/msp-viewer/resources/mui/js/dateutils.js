function truncateDate(date, resolution){
  var i;
  var years = 0, months = 0, days = 1, hours = 0, minutes = 0, seconds = 0, milliseconds = 0;
  switch (resolution) {
    case "millisecond":
      milliseconds = date.getUTCMilliseconds();
    case "second":
      seconds = date.getUTCSeconds();
    case "minute":
      minutes = date.getUTCMinutes();
    case "hour":
      hours = date.getUTCHours();
    case "day":
      days = date.getUTCDate();
    case "month":
      months = date.getUTCMonth();
    case "year":
      years = date.getUTCFullYear();
  }
  return new Date(Date.UTC(years, months, days, hours, minutes, seconds, milliseconds));
}

function dateAdd(date, add) {
  return new Date(Date.UTC(
    date.getUTCFullYear() + (add.years ? add.years : 0),
    date.getUTCMonth() + (add.months ? add.months : 0),
    date.getUTCDate() + (add.days ? add.days : 0),
    date.getUTCHours() + (add.hours ? add.hours : 0),
    date.getUTCMinutes() + (add.minutes ? add.minutes : 0),
    date.getUTCSeconds() + (add.seconds ? add.seconds : 0),
    date.getUTCMilliseconds() + (add.milliseconds ? add.milliseconds : 0)
  ));
}

var dayName = {
  0: "sunday",
  1: "monday",
  2: "tuesday",
  3: "wednesday",
  4: "thursday",
  5: "friday",
  6: "saturday"
};

var monthNames = {
  0: "januari",
  1: "februari",
  2: "march",
  3: "april",
  4: "may",
  5: "june",
  6: "july",
  7: "august",
  8: "september",
  9: "october",
 10: "november",
 11: "december"
};

function formatDate(date, format){

}